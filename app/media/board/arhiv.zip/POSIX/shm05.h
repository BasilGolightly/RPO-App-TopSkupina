#ifndef OS_SHM_NALOGA05
#define OS_SHM_NALOGA05

#define WRITER_MODE 1
#define READER_MODE 2
struct msgStruct{
    char msg[100];
    int status;
};  
typedef struct msgStruct msgStruct;

#endif
