
/*
V rw_writer.c in rw_reader.c pripravite programa rw_writer in rw_reader.

Oba programa uporabljata deljen pomnilnik s celoštevilsko vrednostjo.

Implementirajte rešitev problema bralcev-piscev s semaforji. Več bralcev lahko hkrati bere, pisec pa potrebuje ekskluziven dostop. Podrobnosti preproste implementacije z dvema ključavnicama so opisane na wikipediji.

Program rw_writer prejme število iteracij N. Ustvari deljen pomnilnik in potrebne semaforje (če še ne obstajajo). N-krat zapiše naključno število (1-100) in izpiše "Pisec: zapisal <stevilo>". Med zapisi počaka 3 sekunde.

Zadnji proces, ki se zaključi, odstrani vse vire.
*/

#define _XOPEN_SOURCE 700
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <signal.h>
// struktura
#include "shm09.h"

sem_t *semBralec, *semPom, *semPid;
rwStruct *data;
int pom, running = 1, temp = 0, pid = 0;

// uporabniski signal ctrl+c
void cancel(int sig){
    if(sig == SIGINT) running = 0;
}

int main(int argc, char** argv){
    // UPORABA: ./prod_sem N
    if(argc != 2) return -1;

    const int N = atoi(argv[1]);
    if(N == 0 && argv[1][0] != '0') return -1;

    // odpri semaforje (wikipedia)
    semPom = sem_open("/sem5", O_RDWR);
    semBralec = sem_open("/sem4", O_RDWR);
    semPid = sem_open("/sem6", O_RDWR);
    
    if(semBralec == SEM_FAILED || semPom == SEM_FAILED || semPid == SEM_FAILED){
        perror("Neuspesno odpiranje semaforjev!");
        return -1;
    }

    // odpri pomnilnik
    pom = shm_open("/semMem2", O_RDWR, 0660);
    if(pom == -1){
        perror("Neuspesno odpiranje pomnilnika!\n");
        return -1;
    }

    data = mmap(0, sizeof(rwStruct), PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }

    // Ctrl+c => SIGINT
    struct sigaction act;
    act.sa_handler = cancel;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGINT, &act, NULL);

    // zabelezi proces
    sem_wait(semPid);
    pid = data->pidCount;
    data->pidCount++;
    sem_post(semPid);

    for(int i = 0; i < N; i++){

        // zacetek branja => wikipedia
        sem_wait(semBralec);
        data->b++;
        if(data->b == 1) sem_wait(semPom);
        sem_post(semBralec);

        temp = data->val;
        printf("Bralec: prebral %d\n", temp);
        
        // konec branja => wikipedia
        sem_wait(semBralec);
        data->b--;
        if(data->b == 0) sem_post(semPom);
        sem_post(semBralec);

        // 2. Pocaka 2 sekunde
        sleep(2);
    }

    // preveri ce je zadnji proces
    sem_wait(semPid);
    data->pidCount--;
    pid = data->pidCount;
    sem_post(semPid);

    // zapri vire
    munmap(data, sizeof(rwStruct));
    close(pom);

    sem_close(semBralec);
    sem_close(semPom);
    sem_close(semPid);

    // odstrani vire
    if(pid <= 0){
        sem_unlink("/sem4");
        sem_unlink("/sem5");
        sem_unlink("/sem6");
        shm_unlink("/semMem2");
    }

    return 0;
}
