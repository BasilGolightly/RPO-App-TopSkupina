#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <mqueue.h>

int main(){
    printf("Posiljatelj: zacenjam...\n");
    const int numOfMsg = 5;
    const char* Qname = "/vrsta1";

    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = numOfMsg;
    attr.mq_msgsize = 128;
    attr.mq_curmsgs = 0;

    mqd_t vrsta = mq_open(Qname, O_RDWR, 0777, &attr);
    if(vrsta == (mqd_t)-1){
        perror("Neuspesno odpiranje vrste!\n");
    }

    char buf[128];
    for(int i = 0; i < numOfMsg; i++){
        memset(buf, 0, 128);
        snprintf(buf, 128, "%s %d", "Sporocilo", (i+1));
        
        int send = mq_send(vrsta, buf, sizeof(buf), 0);
        // neuspesno posiljanje 
        if(send == -1){
            printf("Sporocilo: %s spodletelo!\n", buf);
        }
        else{
            printf("Poslano: \"%s\"\n", buf);
        }
    }
    
    printf("Posiljatelj: zakljucujem...\n");
    mq_close(vrsta);
    return 0;
}