#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <string.h>
// HEADER FILE za strukturo
#include "shm05.h"

int main(){
    const char* Mname = "/mem2";
    int pom = shm_open(Mname, O_RDWR, 0660);
    if(pom == -1){
        perror("Neuspesno odpiranje pomnilnika!\n");
        return -1;
    }

    msgStruct* data = mmap(0, sizeof(msgStruct), PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }

    while(1){
        if(data->status == READER_MODE){
            printf("Reader: prejel \"%s\"\n", data->msg);
            // KONEC
            if(strcmp("KONEC", data->msg) == 0){
                data->status = WRITER_MODE;
                break;
            }
            data->status = WRITER_MODE;
        }
    }

    munmap(data, sizeof(msgStruct));
    close(pom);
    shm_unlink(Mname);

    return 0;
}