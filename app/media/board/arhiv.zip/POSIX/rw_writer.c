
/*
V rw_writer.c in rw_reader.c pripravite programa rw_writer in rw_reader.

Oba programa uporabljata deljen pomnilnik s celoštevilsko vrednostjo.

Implementirajte rešitev problema bralcev-piscev s semaforji. Več bralcev lahko hkrati bere, pisec pa potrebuje ekskluziven dostop. Podrobnosti preproste implementacije z dvema ključavnicama so opisane na wikipediji.

Program rw_writer prejme število iteracij N. Ustvari deljen pomnilnik in potrebne semaforje (če še ne obstajajo). N-krat zapiše naključno število (1-100) in izpiše "Pisec: zapisal <stevilo>". Med zapisi počaka 3 sekunde.

Zadnji proces, ki se zaključi, odstrani vse vire.
*/

#define _XOPEN_SOURCE 700
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <signal.h>
// struktura
#include "shm09.h"

sem_t *semBralec, *semPom, *semPid;
rwStruct *data;
int pom, running = 1, temp = 0, pid = 0, createMode = 0;

// uporabniski signal ctrl+c
void cancel(int sig){
    if(sig == SIGINT) running = 0;
}

/* 
Program rw_reader prejme število iteracij N. 

*/
int main(int argc, char** argv){
    // UPORABA: ./prod_sem N
    if(argc != 2) return -1;

    const int N = atoi(argv[1]);
    if(N == 0 && argv[1][0] != '0') return -1;

    // ustvari / odpri semaforje (wikipedia)
    semPom = sem_open("/sem5", O_CREAT, 0660, 1);
    semBralec = sem_open("/sem4", O_CREAT, 0660, 1);
    semPid = sem_open("/sem6", O_CREAT, 0666, 1);

    if(semBralec == SEM_FAILED || semPom == SEM_FAILED){
        semPom = sem_open("/sem5", O_RDWR);
        semBralec = sem_open("/sem4", O_RDWR);
        semPid = sem_open("/sem6", O_RDWR);
        if(semPom == SEM_FAILED || semBralec == SEM_FAILED || semPid == SEM_FAILED){
            perror("Neuspesno ustvarjanje semaforjev!");
            return -1;
        }
    }

    // poskusi ustvariti pomnilnik, ce ne ga samo odpri
    pom = shm_open("/semMem2", O_CREAT | O_RDWR, 0660);
    if(pom == -1){
        pom = shm_open("/semMem2", O_RDWR, 0660);
        if(pom == -1){
            perror("Napaka pri odpiranju/ustvarjanju pomnilnika!\n");
            return -1;
        }
    }
    else {
        ftruncate(pom, sizeof(rwStruct));
        createMode = 1;
    }

    data = mmap(0, sizeof(rwStruct), PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }

    if(createMode){
        data->b = 0;
        data->pidCount = 0;
    }

    // Ctrl+c => SIGINT
    struct sigaction act;
    act.sa_handler = cancel;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGINT, &act, NULL);

    // zabelezi proces
    sem_wait(semPid);
    pid = data->pidCount;
    data->pidCount++;
    sem_post(semPid);

    printf("Potrosnik: cakam na elemente...\n");
    // N-krat nakljucno st => [1, 100]
    for(int i = 0; i < N; i++){
        temp = ((rand() % 100) + 1);

        // 1. cakaj na dostop do bufferja
        sem_wait(semPom);
        data->val = temp;
        printf("Pisec: zapisal %d\n", temp);
        sem_post(semPom);

        // 2. Pocaka 3 sekunde
        sleep(3);
    }

    // preveri ce je zadnji proces
    sem_wait(semPid);
    data->pidCount--;
    pid = data->pidCount;
    sem_post(semPid);

    // zapri vire
    munmap(data, sizeof(rwStruct));
    close(pom);

    sem_close(semBralec);
    sem_close(semPom);
    sem_close(semPid);

    // odstrani vire
    if(pid <= 0){
        sem_unlink("/sem4");
        sem_unlink("/sem5");
        sem_unlink("/sem6");
        shm_unlink("/semMem2");
    }

    return 0;
}
