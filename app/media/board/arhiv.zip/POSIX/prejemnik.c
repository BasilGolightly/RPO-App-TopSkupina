#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <mqueue.h>

int main(){
    const int numOfMsg = 5;
    const char* Qname = "/vrsta1";

    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 5;
    attr.mq_msgsize = 128;
    attr.mq_curmsgs = 0;

    mqd_t vrsta = mq_open(Qname, O_CREAT|O_RDWR, 0660, &attr);
    if(vrsta == (mqd_t)-1){
        perror("Neuspesno ustvarjanje vrste!\n");
        return -1;
    }

    printf("Prejemnik: cakam na sporocila...\n");

    char buf[128];
    for(int i = 0; i < numOfMsg; i++){
        memset(buf, 0, 128);
        ssize_t msgSize = mq_receive(vrsta, buf, sizeof(buf), NULL);
        if(msgSize < 0){
            printf("Spodletelo prejemanje sporocila!\n");
            continue;
        }
        printf("Prejeto: \"%s\"\n", buf);
    }

    printf("Prejemnik: Zakljucujem\n");
    mq_close(vrsta);
    mq_unlink("/vrsta1");
    return 0;
}