#define _XOPEN_SOURCE 700
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <signal.h>
// struktura
#include "shm08.h"

sem_t *sem, *semPolni, *semPrazni;
bufStruct *data;
int pom, running = 1;

// uporabniski signal ctrl+c
void cancel(int sig){
    if(sig == SIGINT) running = 0;
}

int main(){
    const int N = 5;
    // odpri semaforje - 1 za pomnilnik, 1 za polna mesta, 1 za prazna
    sem = sem_open("/sem2", O_RDWR | O_CREAT, 0660, 1);
    semPolni = sem_open("/sem3", O_RDWR | O_CREAT, 0660, 0);
    semPrazni = sem_open("/sem4", O_RDWR | O_CREAT, 0660, N);

    if(sem == SEM_FAILED || semPolni == SEM_FAILED || semPrazni ==  SEM_FAILED){
        perror("Neuspesno ustvarjanje semaforja!");
        return -1;
    }

    // odpri pomnilnik
    pom = shm_open("/semMem1", O_CREAT | O_RDWR, 0660);
    if(pom == -1){
        perror("Neuspesno odpiranje pomnilnika!\n");
        return -1;
    }

    ftruncate(pom, sizeof(bufStruct));

    data = mmap(0, sizeof(bufStruct), PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }

    // Ctrl+c => SIGINT
    struct sigaction act;
    act.sa_handler = cancel;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGINT, &act, NULL);

    data->readIndex = 0;
    data->writeIndex = 0;

    printf("Potrosnik: cakam na elemente...\n");
    while(running){
        // 1. Cakaj na podatke v medpomnilniku in na branje iz pomnlinika
        sem_wait(semPolni);
        sem_wait(sem);

        if(!running) break;
        
        // 2. Preberi stevilo iz predpomnilnika
        int temp = data->arr[data->readIndex];

        // 3. Izpis 
        printf("Potrosnik: vzel %d\n", temp);
        
        // 4. Sprosti prostor v pomnilniku - nov index
        data->readIndex = (data->readIndex+1) % N;
        
        sem_post(sem);
        sem_post(semPrazni);

        // 5. Pocaka 2 sekundi
        sleep(2);
    }

    printf("\nPotrosnik: zakljucujem\n");
    munmap(data, sizeof(bufStruct));
    close(pom);

    // odstrani vse vire
    sem_close(sem);
    sem_close(semPrazni);
    sem_close(semPolni);
    sem_unlink("/sem2");
    sem_unlink("/sem3");
    sem_unlink("/sem4");

    return 0;
}