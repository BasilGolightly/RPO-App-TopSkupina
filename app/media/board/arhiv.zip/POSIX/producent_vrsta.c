#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <mqueue.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char** argv){
    if(argc < 2) return -1;
    
    const int N = atoi(argv[1]);
    if(N <= 0) return -1;

    srand(time(0));

    const char* Qname = "/vrsta4";

    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 5;
    attr.mq_msgsize = 128;
    attr.mq_curmsgs = 0;

    mqd_t vrsta = mq_open(Qname, O_CREAT | O_RDWR, 0777, &attr);
    if(vrsta == (mqd_t)-1){
        perror("Neuspesno odpiranje vrste!\n");
    }

    char buf[50];
    for(int i = 0; i < N; i++){
        memset(buf, 0, sizeof(buf));
        int temp = (rand() % 100) + 1;
        snprintf(buf, sizeof(buf), "%d", temp);

        mq_send(vrsta, buf, strlen(buf)+1, 0);
        printf("Producent: poslal %s\n", buf);
        
        sleep(1);
    }   

    // POSLJI SIGNAL ZA KONEC
    memset(buf, 0, sizeof(buf));
    snprintf(buf, sizeof(buf), "%s", "KONEC");
    mq_send(vrsta, buf, strlen(buf)+1, 0);
    printf("Producent: poslal %s\n", buf);
    
    mq_close(vrsta);
    mq_unlink(Qname);

    return 0;
}