#ifndef OS_SHM_NALOGA09
#define OS_SHM_NALOGA09

// vir: wikipedia
struct rwStruct{
    int val;
    int b;
    int pidCount;
};  
typedef struct rwStruct rwStruct;

#endif