#ifndef OS_SHM_NALOGA08
#define OS_SHM_NALOGA08

struct bufStruct{
    int arr[5];
    int readIndex;
    int writeIndex;
};  
typedef struct bufStruct bufStruct;

#endif