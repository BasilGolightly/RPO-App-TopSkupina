#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <mqueue.h>
#include <stdlib.h>

int main(int argc, char** argv){
    // UPORABA: ./calc_client a op b
    if(argc < 4 && argc != 2) return -1;

    //printf("Parametri: \"%s\", \"%s\", \"%s\"\n", argv[1], argv[2], argv[3]);

    const char* Qname = "/vrsta2";
    const char* Qname2 = "/vrsta3";

    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 5;
    attr.mq_msgsize = 128;
    attr.mq_curmsgs = 0;

    struct mq_attr attr2;
    attr2.mq_flags = 0;
    attr2.mq_maxmsg = 5;
    attr2.mq_msgsize = 256;
    attr2.mq_curmsgs = 0;

    // vrsta za posiljanje
    mqd_t vrsta = mq_open(Qname, O_WRONLY, 0777, &attr);
    if(vrsta == (mqd_t)-1){
        perror("Server: Neuspesno ustvarjanje vrste!\n");
        return -1;
    }

    // vrsta za prejemanje rezultatov
    mqd_t vrsta2 = mq_open(Qname2, O_RDONLY, 0777, &attr2);
    if(vrsta2 == (mqd_t)-1){
        perror("Server: Neuspesno ustvarjanje druge vrste!\n");
        return -1;
    }

    // KONEC
    if(argc == 2){
        char konecBuf[10];
        memset(konecBuf, 0, sizeof(konecBuf));
        strcpy(konecBuf, argv[1]);

        //printf("%s\n", konecBuf);

        if(strcmp(konecBuf, "KONEC") == 0) {
            mq_send(vrsta, argv[1], strlen(argv[1])+1, 0);
            return 0;
        }
        return -1;
    }

    char res[256], a[128], b[128], op[128];
    memset(a, 0, sizeof(a));
    memset(op, 0, sizeof(op));
    memset(b, 0, sizeof(b));
    memset(res, 0, sizeof(res));
    
    strcpy(a, argv[1]);
    strcpy(op, argv[2]);
    //printf("Operacija: \"%s\"\n", op);
    strcpy(b, argv[3]); 

    // 1. POSLJI RACUN => a, operacija, nato b
    ssize_t aSize = mq_send(vrsta, a, sizeof(a), 0);
    if(aSize < 0){
        perror("Napaka pri pošiljanju prvega operanda\n");
        mq_close(vrsta);
        return -1;
    }

    ssize_t opSize = mq_send(vrsta, op, sizeof(op), 0);
    if(opSize < 0){
        perror("Napaka pri pošiljanju drugega operanda\n");
        mq_close(vrsta);
        return -1;
    }

    ssize_t bSize = mq_send(vrsta, b, sizeof(b), 0);
    if(bSize < 0){
        perror("Napaka pri pošiljanju operacije\n");
        mq_close(vrsta);
        return -1;
    }

    // 2. PREJMI REZULTAT
    ssize_t resSize = mq_receive(vrsta2, res, sizeof(res), 0);
    if(resSize < 0){
        perror("Napaka pri prejemanju rezultata!\n");
        mq_close(vrsta);
        return -1;
    }

    // 3. IZPISI REZULTAT
    printf("%s\n", res);

    mq_close(vrsta);
    return 0;
}