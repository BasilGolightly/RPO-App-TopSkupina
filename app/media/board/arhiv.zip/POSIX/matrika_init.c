#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <time.h>

int main(int argc, char **argv){
    // UPORABA: /matrika_init N M
    if(argc != 3) return -1;

    srand(time(0));

    const char* Mname = "/mem3";
    int pom = shm_open(Mname, O_RDWR|O_CREAT, 0660);
    if(pom == -1){
        perror("Neuspesno odpiranje pomnilnika!\n");
        return -1;
    }

    const int N = atoi(argv[1]), M = atoi(argv[2]);
    if(N == 0 || M == 0){
        printf("Neveljavna parametra!\n");
        return -1;
    }
    
    int numOfInts = (M*N) + 2;
    ftruncate(pom, sizeof(int) * numOfInts);

    int* data = mmap(0, sizeof(int) * numOfInts, PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }

    // Zapisi N, M, nato vrednosti matrike
    data[0] = N;
    data[1] = M;
    for(int i = 0; i < N*M; i++){
        data[(i+2)] = ((rand() % 10) + 1);
    }

    printf("Matrika incializirana: %d x %d\n", N, M);
    close(pom);
    
    return 0;
}
