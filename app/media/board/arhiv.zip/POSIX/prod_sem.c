#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <time.h>
// struktura
#include "shm08.h"

int main(int argc, char** argv){
    // UPORABA: ./prod_sem N
    if(argc != 2) return -1;

    const int N = atoi(argv[1]);
    if(N == 0 && argv[1][0] != '0') return -1;

    srand(time(0));

    // odpri semaforje - 1 za pomnilnik, 1 za polna mesta, 1 za prazna
    sem_t *sem, *semPolni, *semPrazni;
    sem = sem_open("/sem2", O_RDWR);
    semPolni = sem_open("/sem3", O_RDWR);
    semPrazni = sem_open("/sem4", O_RDWR);

    if(sem == SEM_FAILED || semPolni == SEM_FAILED || semPrazni ==  SEM_FAILED){
        perror("Neuspesno ustvarjanje semaforja!");
        return -1;
    }

    // odpri pomnilnik
    int pom = shm_open("/semMem1", O_CREAT | O_RDWR, 0660);
    if(pom == -1){
        perror("Neuspesno odpiranje pomnilnika!\n");
        return -1;
    }

    bufStruct *data = mmap(0, sizeof(bufStruct), PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }

    // N-krat operacija, zapisi v medpomnilnik x => [1, 100]
    for(int i = 0; i < N; i++){
        int temp = ((rand() % 100) + 1);

        // 1. Cakaj na prostor v bufferju, in na zapis
        sem_wait(semPrazni);
        sem_wait(sem);

        // 2. Zapisi stevilo, spremeni index
        data->arr[data->writeIndex] = temp;
        data->writeIndex = (data->writeIndex+1) % 5;

        // 3. Izpis
        printf("Producent: dodal %d\n", temp);

        sem_post(semPolni);
        sem_post(sem);

        // 4. Pocaka 1 sekundo
        sleep(1);
    }
    
    // zapri vire
    munmap(data, sizeof(bufStruct));
    close(pom);

    sem_close(sem);
    sem_close(semPolni);
    sem_close(semPrazni);

    return 0;
}