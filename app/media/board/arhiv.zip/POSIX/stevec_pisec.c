#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/shm.h>


int main(){
    const int N = 5;
    int temp = 0;

    const char* Mname = "/mem1";
    int pom = shm_open(Mname, O_RDWR|O_CREAT, 0660);
    if(pom == -1){
        perror("Neuspesno odpiranje pomnilnika!\n");
        return -1;
    }

    ftruncate(pom, sizeof(int));

    int *data = mmap(0, sizeof(int), PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }
    data[0] = temp;
    
    for(temp++; temp <= N; temp++){
        data[0] = temp;
        printf("Pisec: stevec %d\n", temp);
        sleep(2);
    }

    munmap(data, sizeof(int));
    close(pom);

    return 0;
}