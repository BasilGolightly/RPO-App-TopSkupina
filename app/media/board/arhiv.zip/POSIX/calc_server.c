#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <mqueue.h>
#include <unistd.h>
#include <stdlib.h>

int main(){
    printf("Server: cakam na zahtevke...\n");
    const char* Qname = "/vrsta2";
    const char* Qname2 = "/vrsta3";

    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 5;
    attr.mq_msgsize = 128;
    attr.mq_curmsgs = 0;

    struct mq_attr attr2;
    attr2.mq_flags = 0;
    attr2.mq_maxmsg = 5;
    attr2.mq_msgsize = 256;
    attr2.mq_curmsgs = 0;

    // vrsta za prejemanje racunov
    mqd_t vrsta = mq_open(Qname, O_CREAT|O_RDONLY, 0777, &attr);
    if(vrsta == (mqd_t)-1){
        perror("Server: Neuspesno ustvarjanje vrste!\n");
        return -1;
    }

    // vrsta za posiljanje rezultatov
    mqd_t vrsta2 = mq_open(Qname2, O_CREAT|O_WRONLY, 0777, &attr2);
    if(vrsta2 == (mqd_t)-1){
        perror("Server: Neuspesno ustvarjanje druge vrste!\n");
        return -1;
    }

    char a[128];
    char op[128];
    char b[128];
    char res[256];

    while(1){
        memset(a, 0, sizeof(a));
        memset(b, 0, sizeof(b));
        memset(op, 0, sizeof(op));

        // 1. PRVI OPERAND
        ssize_t aSize = mq_receive(vrsta, a, sizeof(a), NULL);
        if(aSize < 0){
            perror("Server: Spodletelo prejemanje a!\n");
            printf("%s\n", a);
            break;
        }

        // preveri ce je "KONEC"
        if(strcmp("KONEC", a) == 0){
            break;
        }

        // 2. OPERACIJA
        ssize_t opSize = mq_receive(vrsta, op, sizeof(op), NULL);
        if(opSize < 0){
            perror("Server: Spodletelo prejemanje operacije!\n");
            break;
        }

        // 3. DRUGI OPERAND
        ssize_t bSize = mq_receive(vrsta, b, sizeof(b), NULL);
        if(bSize < 0){
            perror("Server: Spodletelo prejemanje b!\n");
            break;
        }   

        // 4. kalkulacija
        int result = 0;
        int aInt = atoi(a);
        int bInt = atoi(b);

        if(aInt == 0 || bInt == 0){
            printf("Server: Neveljaven operand(i)!\n");
            printf("Server: Operandi => \"%s\", \"%s\", \"%s\"\n", a, op, b);
            continue;
        }

        if(!strcmp(op, "+")){
            result = aInt + bInt;
        }
        else if(!strcmp(op, "-")){
            result = aInt - bInt;
        }
        else if(!strcmp(op, "/")){
            result = aInt / bInt;
        }
        else if(!strcmp(op, "*")){
            result = aInt * bInt;
        }
        else{
            printf("Server: Neveljavnja operacija!\n");
            continue;
        }

        memset(res, 0, sizeof(res));
        snprintf(res, sizeof(res), "Rezultat: %d", result);

        // POSLJI
        ssize_t resSend = mq_send(vrsta2, res, strlen(res)+1, 0);
        if(resSend < 0){
            perror("Server: neuspesno posiljanje rezultata!\n");
            printf("Server: Pripravljen rezultat => \"%s\"\n", res);
            continue;
        }

        printf("Server: %d %s %d = %d\n", aInt, op, bInt, result);

        sleep(1);
    }

    printf("Server: Zakljucujem\n");
    mq_close(vrsta);
    mq_close(vrsta2);
    mq_unlink("/vrsta2");
    mq_unlink("/vrsta3");
    return 0;
}