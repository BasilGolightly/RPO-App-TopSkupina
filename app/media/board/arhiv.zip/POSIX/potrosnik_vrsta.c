#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <mqueue.h>
#include <stdlib.h>

int main(){
    int total = 0;
    const char* Qname = "/vrsta4";

    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 5;
    attr.mq_msgsize = 128;
    attr.mq_curmsgs = 0;

    mqd_t vrsta = mq_open(Qname, O_CREAT | O_RDWR, 0777, &attr);
    if(vrsta == (mqd_t)-1){
        perror("Neuspesno odpiranje vrste!\n");
    }

    char buf[128];

    while(1){
        memset(buf, 0, sizeof(buf));
        ssize_t recvSize = mq_receive(vrsta, buf, sizeof(buf), 0);
        if(recvSize <= 0){
            perror("Potrosnik: Spodletelo prejemanje stevilke!\n");
            continue;
        }

        // SIGNAL ZA KONEC
        if(strcmp(buf, "KONEC") == 0){
            printf("Potrosnik: koncna vsota = %d\n", total);
            break;
        }
        
        int temp = 0;
        temp = atoi(buf);
        total += temp;
        
        printf("Potrosnik: prejel %d, vsota = %d\n", temp, total);
    }
    
    mq_close(vrsta);
    
    return 0;
}