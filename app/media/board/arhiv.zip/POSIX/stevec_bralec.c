#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/shm.h>


int main(){
    const int N = 10;
    int temp = 0;

    const char* Mname = "/mem1";
    int pom = shm_open(Mname, O_RDWR, 0660);
    if(pom == -1){
        perror("Neuspesno odpiranje pomnilnika!\n");
        return -1;
    }

    int *data = mmap(0, sizeof(int), PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }
    
    for(int i = 0; i < N; i++){
        temp = data[0];
        printf("Bralec: stevec %d\n", temp);
        sleep(1);
    }

    munmap(data, sizeof(int));
    close(pom);
    shm_unlink(Mname);

    return 0;
}