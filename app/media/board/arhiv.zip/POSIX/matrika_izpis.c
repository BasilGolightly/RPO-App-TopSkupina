#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <time.h>

int main(){
    const char* Mname = "/mem3";
    int pom = shm_open(Mname, O_RDWR, 0660);
    if(pom == -1){
        perror("Neuspesno odpiranje pomnilnika!\n");
        return -1;
    }

    int* data = mmap(0, sizeof(int) * 2, PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }

    const int N = data[0], M = data[1];
    int numOfInts = 2 + (M*N);

    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++){
            int currIndex = ((i*M) + j) + 2;
            printf("%d ", data[currIndex]);
        }
        printf("\n");
    }

    munmap(data, sizeof(numOfInts));
    close(pom);
    shm_unlink(Mname);
    
    return 0;
}
