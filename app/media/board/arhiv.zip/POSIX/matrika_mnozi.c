#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <time.h>

int main(int argc, char **argv){
    // UPORABA: /matrika_mnozi factor
    if(argc != 2) return -1;

    const int factor = atoi(argv[1]);
    if(factor == 0) return -1;

    const char* Mname = "/mem3";
    int pom = shm_open(Mname, O_RDWR, 0660);
    if(pom == -1){
        perror("Neuspesno odpiranje pomnilnika!\n");
        return -1;
    }

    int* data = mmap(0, sizeof(int) * 2, PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }

    const int N = data[0], M = data[1];

    for(int i = 0; i < N*M; i++){
        data[i+2] *= factor;
    }

    printf("Matrika mnozena s: %d\n", factor);
    close(pom);
    
    return 0;
}
