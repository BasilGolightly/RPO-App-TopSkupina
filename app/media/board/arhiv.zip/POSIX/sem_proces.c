#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <semaphore.h>

int main(int argc, char** argv){
    if(argc != 2) return -1;

    const int pid = atoi(argv[1]);
    if(pid == 0 && argv[1][0] != '0') return -1;

    const int N = 5;

    sem_t* sem; 
    
    if(pid == 0) sem = sem_open("/sem1", O_CREAT|O_RDWR, 0660, 1);
    else sem = sem_open("/sem1", O_RDWR, 0660, 0);
    if(sem == SEM_FAILED){
        perror("Neuspesno ustvarjanje semaforja!");
        return -1;
    }

    for(int i = 0; i < N; i++){
        if(sem_wait(sem) == -1){
            perror("Napaka pri cakanju na semafor!\n");
            break;
        }
        printf("Proces %d: vstop v kriticno sekcijo\n", pid);
        sleep(1);
        printf("Proces %d: izstop iz kriticne sekcije\n", pid);
        if(sem_post(sem) == -1){
            perror("Napaka pri sproscanju semaforja!\n");
            break;
        }
        sleep(1);
    }

    sem_close(sem);
    if(pid == 0) sem_unlink("/sem1");

    return 0;
}