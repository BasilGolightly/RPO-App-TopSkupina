#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <string.h>
// HEADER FILE za strukturo
#include "shm05.h"

int main(){
    const char* Mname = "/mem2";
    int pom = shm_open(Mname, O_RDWR|O_CREAT, 0660);
    struct msgStruct temp;
    temp.status = WRITER_MODE;
    if(pom == -1){
        perror("Neuspesno odpiranje pomnilnika!\n");
        return -1;
    }

    ftruncate(pom, sizeof(msgStruct));

    msgStruct* data = mmap(0, sizeof(msgStruct), PROT_READ|PROT_WRITE, MAP_SHARED, pom, 0);
    if(data == MAP_FAILED){
        perror("Neuspesna preslikava pomnilnika!\n");
        return -1;
    }
    data[0] = temp;

    char buf[100];
    while(1){
        if(data->status == WRITER_MODE){
            memset(buf, 0, sizeof(buf));
            // MESSAGE
            if(scanf("%s", buf) == 1){
                strcpy(data->msg, buf);
                printf("Writer: poslal \"%s\"\n", data->msg);
                data->status = READER_MODE;
                continue;
            }
            // KONEC VHODA
            else{
                memset(buf, 0, sizeof(buf));
                strcpy(data->msg, "KONEC");
                printf("Writer: poslal \"%s\"\n", data->msg);
                data->status = READER_MODE;
                break;
            }
        }
        sleep(1);
    }    

    close(pom);

    return 0;
}